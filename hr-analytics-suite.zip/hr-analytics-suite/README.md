# HR Analytics Suite

![CI](https://github.com/jayan2005-ux/hr-analytics-suite/actions/workflows/ci.yml/badge.svg)

Two end-to-end HR analytics projects in one repo, built with Python, scikit-learn, SHAP and Streamlit.

| Project | What it does |
|---|---|
| **Attrition Prediction** | Predicts which employees are likely to leave and explains why (SHAP) |
| **AI Resume Screener** | Ranks resumes against a job description and audits the shortlist for bias |

## Quick start
```bash
git clone https://github.com/jayan2005-ux/hr-analytics-suite.git
cd hr-analytics-suite
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Project 1
python attrition_prediction/train.py
streamlit run attrition_prediction/app.py

# Project 2
streamlit run resume_screener/app.py

# Tests
pytest -q
```

## 1. Attrition Prediction
- Gradient boosting model inside a single sklearn Pipeline (one-hot encoding + classifier)
- Per-employee risk score with a SHAP waterfall explaining the drivers
- Batch CSV upload, risk bands (Low / Medium / High), department-level risk, global SHAP summary
- Runs on a synthetic dataset by default. For the real IBM HR Analytics data:
  `python attrition_prediction/train.py --data WA_Fn-UseC_-HR-Employee-Attrition.csv`

## 2. AI Resume Screener
- Semantic matching with sentence-transformers (`all-MiniLM-L6-v2`), automatic TF-IDF fallback
- Hybrid score = semantic similarity + skill coverage (adjustable weight)
- Missing-skills column for each candidate
- Blind screening mode (strips name, email, phone)
- Bias audit: selection rate and impact ratio per group using the four-fifths (80%) rule

## Project structure
```
attrition_prediction/   train.py, app.py, data_gen.py
resume_screener/        screener.py, app.py
tests/                  pytest suites for both projects
.github/workflows/      CI (train + tests on every push)
```

## Results
> Add your metrics here after training on the real IBM dataset (ROC-AUC, recall at chosen threshold), plus a screenshot of each dashboard in `docs/`.

## Roadmap
- [ ] XGBoost / LightGBM comparison and threshold tuning
- [ ] PDF / DOCX resume parsing
- [ ] Name-swap bias test for the screener
- [ ] Deploy both apps on Streamlit Community Cloud

## Responsible use
These are decision-support demos, not hiring or firing systems. Keep a human in the loop and review outputs for fairness before any real-world use.

## Author
Jayan Shrivastava · [LinkedIn](https://linkedin.com/in/jayan-shrivastava-189076406) · [GitHub](https://github.com/jayan2005-ux)

License: MIT
