import os, joblib, shap, numpy as np, pandas as pd, streamlit as st
import matplotlib.pyplot as plt

st.set_page_config(page_title="Attrition Predictor", layout="wide")
st.title("Employee Attrition Predictor")

bundle = joblib.load(os.path.join(os.path.dirname(os.path.abspath(__file__)), "model.joblib"))
model, cols, sample = bundle["model"], bundle["columns"], bundle["sample"]
pre, clf = model.named_steps["pre"], model.named_steps["clf"]
names = pre.get_feature_names_out()

@st.cache_resource
def explainer():
    return shap.TreeExplainer(clf)

def transform(df):
    X = pre.transform(df)
    return X.toarray() if hasattr(X, "toarray") else X

tab1, tab2 = st.tabs(["Single employee", "Batch / risk dashboard"])

with tab1:
    st.subheader("Enter employee details")
    row = {}
    c = st.columns(3)
    for i, col in enumerate(cols):
        with c[i % 3]:
            if sample[col].dtype == object:
                row[col] = st.selectbox(col, sorted(sample[col].unique()))
            else:
                row[col] = st.number_input(col, value=int(sample[col].median()))
    X = pd.DataFrame([row])
    p = model.predict_proba(X)[0, 1]
    st.metric("Attrition risk", f"{p:.0%}")
    st.progress(float(p))
    sv = explainer()(transform(X))
    sv.feature_names = list(names)
    fig, ax = plt.subplots()
    shap.plots.waterfall(sv[0], max_display=10, show=False)
    st.pyplot(plt.gcf(), clear_figure=True)
    st.caption("Red bars push risk up, blue push it down.")

with tab2:
    up = st.file_uploader("Upload employee CSV (no Attrition column needed)", type="csv")
    data = pd.read_csv(up) if up else sample
    data = data[[c for c in cols if c in data.columns]]
    data["risk"] = model.predict_proba(data)[:, 1]
    data["band"] = pd.cut(data.risk, [0, .3, .6, 1], labels=["Low", "Medium", "High"])
    a, b = st.columns(2)
    a.bar_chart(data.band.value_counts())
    if "Department" in data:
        b.bar_chart(data.groupby("Department").risk.mean())
    st.dataframe(data.sort_values("risk", ascending=False).head(25))
    st.subheader("Global drivers")
    sv = explainer()(transform(data.drop(columns=["risk", "band"])))
    shap.summary_plot(sv.values, features=sv.data, feature_names=list(names), show=False)
    st.pyplot(plt.gcf(), clear_figure=True)
