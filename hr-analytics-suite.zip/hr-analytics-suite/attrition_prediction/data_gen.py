"""Synthetic data in the IBM HR Analytics schema (so the project runs out of the box).
To use the real dataset, download WA_Fn-UseC_-HR-Employee-Attrition.csv from Kaggle
and pass --data path/to/file.csv to train.py."""
import numpy as np, pandas as pd

def make(n=1500, seed=42):
    r = np.random.default_rng(seed)
    df = pd.DataFrame({
        "Age": r.integers(18, 60, n),
        "Department": r.choice(["Sales", "Research & Development", "Human Resources"], n, p=[.3, .6, .1]),
        "JobRole": r.choice(["Sales Executive", "Research Scientist", "Laboratory Technician",
                             "Manager", "Human Resources", "Developer"], n),
        "MonthlyIncome": r.normal(6500, 3000, n).clip(1500, 20000).round(),
        "OverTime": r.choice(["Yes", "No"], n, p=[.28, .72]),
        "JobSatisfaction": r.integers(1, 5, n),
        "WorkLifeBalance": r.integers(1, 5, n),
        "EnvironmentSatisfaction": r.integers(1, 5, n),
        "YearsAtCompany": r.integers(0, 30, n),
        "YearsSinceLastPromotion": r.integers(0, 12, n),
        "DistanceFromHome": r.integers(1, 30, n),
        "NumCompaniesWorked": r.integers(0, 9, n),
        "TotalWorkingYears": r.integers(0, 35, n),
        "BusinessTravel": r.choice(["Non-Travel", "Travel_Rarely", "Travel_Frequently"], n, p=[.1, .7, .2]),
        "MaritalStatus": r.choice(["Single", "Married", "Divorced"], n),
    })
    z = (-1.6 + 1.1*(df.OverTime == "Yes") - 0.00025*(df.MonthlyIncome - 6500)
         - 0.45*(df.JobSatisfaction - 2.5) - 0.35*(df.WorkLifeBalance - 2.5)
         + 0.06*df.YearsSinceLastPromotion + 0.03*df.DistanceFromHome
         + 0.12*df.NumCompaniesWorked - 0.04*df.YearsAtCompany
         + 0.7*(df.BusinessTravel == "Travel_Frequently") + 0.5*(df.MaritalStatus == "Single"))
    df["Attrition"] = np.where(r.random(n) < 1/(1+np.exp(-z)), "Yes", "No")
    return df

if __name__ == "__main__":
    make().to_csv("hr_attrition.csv", index=False)
