import argparse, os, joblib, pandas as pd, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import GradientBoostingClassifier
import sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from data_gen import make

p = argparse.ArgumentParser()
p.add_argument("--data", default=None)
a = p.parse_args()

df = pd.read_csv(a.data) if a.data else make()
df = df.drop(columns=[c for c in ["EmployeeCount", "EmployeeNumber", "Over18", "StandardHours"] if c in df])
y = (df.pop("Attrition") == "Yes").astype(int)
cat = df.select_dtypes("object").columns.tolist()
pre = ColumnTransformer([("cat", OneHotEncoder(handle_unknown="ignore"), cat)], remainder="passthrough")
model = Pipeline([("pre", pre), ("clf", GradientBoostingClassifier(random_state=42))])

Xtr, Xte, ytr, yte = train_test_split(df, y, test_size=.2, stratify=y, random_state=42)
model.fit(Xtr, ytr)
proba = model.predict_proba(Xte)[:, 1]
print(classification_report(yte, proba > .35))
print("ROC-AUC:", round(roc_auc_score(yte, proba), 3))

joblib.dump({"model": model, "columns": df.columns.tolist(), "sample": df.sample(200, random_state=1)}, os.path.join(os.path.dirname(os.path.abspath(__file__)), "model.joblib"))
print("saved model.joblib")
