#!/usr/bin/env bash
# 1) Create an EMPTY repo named hr-analytics-suite at https://github.com/new (no README, no license)
# 2) Run this script from inside this folder
set -e
git init -b main
git add .
git commit -m "Initial commit: HR Analytics Suite (attrition prediction + resume screener)"
git remote add origin https://github.com/jayan2005-ux/hr-analytics-suite.git
git push -u origin main
