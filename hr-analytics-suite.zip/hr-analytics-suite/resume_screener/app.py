import pandas as pd, streamlit as st
from screener import rank, bias_audit, demo_data

st.set_page_config(page_title="Resume Screener", layout="wide")
st.title("AI Resume Screener with Bias Audit")

jd = st.text_area("Job description", "Looking for a data analyst with python, sql, statistics, "
                  "machine learning, power bi and strong communication skills.", height=120)
up = st.file_uploader("Resumes CSV (columns: id, text, optional gender / college_tier)", type="csv")
df = pd.read_csv(up) if up else demo_data()
if not up:
    st.info("Using demo data. Upload a CSV to use your own.")

c1, c2, c3 = st.columns(3)
blind = c1.checkbox("Blind screening (strip name/email/phone)", True)
use_tf = c2.checkbox("Use sentence-transformers if available", True)
w = c3.slider("Semantic weight", 0.0, 1.0, 0.7)

res = rank(df, jd, blind=blind, use_transformer=use_tf, w_sem=w)
st.caption(f"Embedding backend: {res.backend[0]}")
st.subheader("Ranked candidates")
st.dataframe(res.drop(columns=["text", "backend"]).head(30), use_container_width=True)

st.subheader("Bias audit (top 20% shortlist)")
groups = [c for c in ["gender", "college_tier"] if c in res]
top_frac = st.slider("Shortlist size", 0.05, 0.5, 0.2)
for g in groups:
    a = bias_audit(res, g, top_frac)
    st.write(f"**{g}**")
    st.dataframe(a)
    if a["flag_(<0.8)"].any():
        st.warning(f"Possible adverse impact on {g}: impact ratio below 0.8")
    else:
        st.success(f"No adverse impact flagged on {g}")
st.caption("Tip: run with blind on vs off and compare the audit. That delta is your bias story.")
