"""Resume screening: semantic ranking + skill-gap + bias audit."""
import re, numpy as np, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

SKILLS = ["python", "java", "sql", "machine learning", "deep learning", "nlp", "react", "node",
          "aws", "docker", "excel", "power bi", "tableau", "statistics", "communication",
          "leadership", "recruitment", "hr analytics", "git", "django", "flask", "tensorflow"]

def get_embedder(prefer_transformer=True):
    """Try sentence-transformers; fall back to TF-IDF so it always runs."""
    if prefer_transformer:
        try:
            from sentence_transformers import SentenceTransformer
            m = SentenceTransformer("all-MiniLM-L6-v2")
            return lambda texts: m.encode(texts, normalize_embeddings=True), "sentence-transformers"
        except Exception:
            pass
    vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    state = {"fit": False}
    def f(texts):
        if not state["fit"]:
            vec.fit(texts); state["fit"] = True
        return vec.transform(texts)
    return f, "tfidf"

def extract_skills(text):
    t = text.lower()
    return {s for s in SKILLS if re.search(r"\b" + re.escape(s) + r"\b", t)}

def anonymize(text):
    """Blind the screening: strip emails, phones, and a leading 'Name:' line."""
    text = re.sub(r"\S+@\S+", " ", text)
    text = re.sub(r"\+?\d[\d\s\-]{8,}\d", " ", text)
    text = re.sub(r"(?im)^name:.*$", " ", text)
    return text

def rank(resumes: pd.DataFrame, jd: str, blind=True, use_transformer=True, w_sem=0.7):
    """resumes needs columns: id, text. Returns df with score, semantic, skill_match, missing_skills."""
    embed, backend = get_embedder(use_transformer)
    texts = resumes.text.map(anonymize) if blind else resumes.text
    E = embed(list(texts) + [jd])
    sem = cosine_similarity(E[:-1], E[-1]).ravel()
    jd_sk = extract_skills(jd)
    skm, miss = [], []
    for t in texts:
        have = extract_skills(t)
        skm.append(len(have & jd_sk) / max(len(jd_sk), 1))
        miss.append(", ".join(sorted(jd_sk - have)))
    out = resumes.copy()
    out["semantic"], out["skill_match"], out["missing_skills"] = sem, skm, miss
    s = (sem - sem.min()) / (np.ptp(sem) + 1e-9)
    out["score"] = w_sem * s + (1 - w_sem) * np.array(skm)
    out["backend"] = backend
    return out.sort_values("score", ascending=False).reset_index(drop=True)

def bias_audit(ranked: pd.DataFrame, group_col: str, top_frac=0.2):
    """Selection rate per group in the top-k + four-fifths (80%) rule check."""
    k = max(1, int(len(ranked) * top_frac))
    top = ranked.head(k)
    rates = (top[group_col].value_counts() / ranked[group_col].value_counts()).fillna(0)
    ref = rates.max()
    res = pd.DataFrame({"selection_rate": rates, "impact_ratio": rates / (ref if ref else 1)})
    res["flag_(<0.8)"] = res.impact_ratio < 0.8
    return res.round(3)

def demo_data(n=120, seed=0):
    r = np.random.default_rng(seed)
    first = ["Aarav", "Priya", "Rohan", "Sneha", "Kabir", "Ananya", "Vikram", "Meera"]
    colleges = ["Tier1", "Tier2", "Tier3"]
    pool = [s for s in SKILLS if s not in ("recruitment", "hr analytics")]
    rows = []
    for i in range(n):
        sk = r.choice(pool, r.integers(3, 9), replace=False)
        g = r.choice(["Male", "Female"])
        rows.append({"id": i, "gender": g, "college_tier": r.choice(colleges, p=[.2, .4, .4]),
                     "text": f"Name: {r.choice(first)}\nExperience: {r.integers(0, 8)} years\nSkills: {', '.join(sk)}\n"
                             f"Built projects using {sk[0]} and {sk[1]}. Email: x{i}@mail.com"})
    return pd.DataFrame(rows)
