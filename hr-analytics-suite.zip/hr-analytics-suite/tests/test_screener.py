import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent / "resume_screener"))
import pandas as pd
from screener import rank, bias_audit, anonymize, extract_skills, demo_data

JD = "python sql statistics machine learning communication"

def test_anonymize_strips_pii():
    t = anonymize("Name: Rohan\nSkills: python\nEmail: a@b.com Phone: +91 98765 43210")
    assert "Rohan" not in t and "a@b.com" not in t and "98765" not in t

def test_extract_skills():
    assert {"python", "sql"} <= extract_skills("I know Python and SQL")

def test_best_match_ranks_first():
    df = pd.DataFrame({"id": [1, 2], "text": [
        "Skills: python, sql, statistics, machine learning, communication",
        "Skills: java, react, docker"]})
    r = rank(df, JD, use_transformer=False)
    assert r.iloc[0].id == 1

def test_bias_audit_columns():
    r = rank(demo_data(100), JD, use_transformer=False)
    a = bias_audit(r, "gender")
    assert {"selection_rate", "impact_ratio", "flag_(<0.8)"} <= set(a.columns)
