import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent / "attrition_prediction"))
from data_gen import make

def test_synthetic_schema():
    df = make(200)
    assert len(df) == 200
    assert set(df.Attrition.unique()) <= {"Yes", "No"}
    assert {"Age", "OverTime", "MonthlyIncome"} <= set(df.columns)

def test_attrition_rate_reasonable():
    rate = (make(1500).Attrition == "Yes").mean()
    assert 0.05 < rate < 0.6
